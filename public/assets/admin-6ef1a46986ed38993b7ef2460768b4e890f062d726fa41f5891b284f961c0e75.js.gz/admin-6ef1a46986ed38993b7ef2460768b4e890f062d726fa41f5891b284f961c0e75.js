// app/javascript/admin.js
import "admin-lte/dist/js/adminlte.min";

